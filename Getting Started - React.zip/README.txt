## CONTENIDO

REACTLAB.docx -> Explicación paso a paso de las prácticas de React.
REACTLAB.rar -> Laboratorio React con la solución final.
REACTPATHS.ppt -> Rutas de aprendizaje de React agrupadas por niveles.
CSS -> Estilos CSS de los componentes para las prácticas de react

Empieza abriendo REACTPATHS.ppt para revisar los cursos que tienes disponibles.
Si quieres realizar las prácticas de React sigue los pasos en REACTLAB.docx


## PREREQUISITOS


Instalación de Node.js y NPM
Descargar Node.js, se instalarán en nuestra máquina: 
-	NODE > = 8.10
-	NPM > = 5.6


## Empezar LAB :

En una línea comandos:

1.npx create-react-app my-app 
2.cd my-app
3.npm start


## Ejecutar solución finalizada REACTLAB.rar

1. Descomprimir REACTLAB.rar
2. Abrir línea comandos en la carpeta raíz
3. Ejecutar comando : npm install
3. Ejecutar comando : npm start